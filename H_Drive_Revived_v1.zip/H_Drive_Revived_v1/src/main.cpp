
// ---- START VEXCODE CONFIGURED DEVICES ----
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"

  using namespace vex;

  int main() 
{
    // Initializing Robot Configuration. DO NOT REMOVE!
    vexcodeInit();
    
  

  /*----------------------------------------------------------------------------*/
  /*                                                                            */
  /*    Module:       main.cpp                                                  */
  /*    Author:       C:\Users\jacks                                            */
  /*    Created:      Wed Oct 23 2019                                           */
  /*    Description:  V5 project                                                */
  /*                                                                            */
  /*----------------------------------------------------------------------------*/

  // ---- START VEXCODE CONFIGURED DEVICES ----
  // Robot Configuration:
  // [Name]               [Type]        [Port(s)]
  // ---- END VEXCODE CONFIGURED DEVICES ----
  
  // A global instance of vex::brain used for printing to the V5 brain screen
  vex::brain       Brain;
  
  // define your global instances of motors and other devices here
  vex::motor LeftMotor = vex::motor(vex::PORT12);
  vex::motor RightMotor = vex::motor(vex::PORT19);
  vex::motor StrafeMotor = vex::motor(vex::PORT15);
  vex::motor CubeAngleMotor = vex::motor(vex::PORT2); 
  vex::motor LeftLiftMotor = vex::motor(vex::PORT1);
  vex::motor RightLiftMotor = vex::motor(vex::PORT21); 
  vex::motor LeftIntakeMotor = vex::motor(vex::PORT11);
  vex::motor RightIntakeMotor = vex::motor(vex::PORT20);

  vex::controller Controller (vex::controllerType::primary);
  vex::controller Controller2 (vex::controllerType::partner);
  int deadzone = 20;
  int cubeAngleSpeedPCT = 25;
  int liftSpeedPCT = 100;
  int intakeSpeedPCT = 100;
  while(1) 
  { 
    // Drivetrain Section (Arcade Style)
    //Axis 2 (right joystick horizontal acis) of the controller makes the robot moves forward or backward and Ax
    if(abs(Controller.Axis2.position()) > deadzone || abs(Controller.Axis1.position()) > deadzone )
     {
         LeftMotor.spin(vex::directionType::fwd, Controller.Axis2.position(), vex::percentUnits::pct);
         RightMotor.spin(vex::directionType::rev, Controller.Axis2.position(), vex::percentUnits::pct);
         StrafeMotor.spin(vex::directionType::rev, Controller.Axis1.position(), vex::percentUnits::pct);
       }
       else if(abs(Controller.Axis4.position()) > deadzone)
       {
         LeftMotor.spin(vex::directionType::fwd, Controller.Axis4.position()/3, vex::percentUnits::pct);
         RightMotor.spin(vex::directionType::fwd, Controller.Axis4.position()/3, vex::percentUnits::pct);
         StrafeMotor.spin(vex::directionType::fwd, Controller.Axis4.position()/3, vex::percentUnits::pct);
       }
       else
       {
         LeftMotor.stop();
         RightMotor.stop();
         StrafeMotor.stop();
       }
 
       // Cube Angle Section
       CubeAngleMotor.setVelocity(cubeAngleSpeedPCT, vex::percentUnits::pct);
       
       if(Controller.ButtonL1.pressing())
       {
         CubeAngleMotor.spin(vex::directionType::fwd);
       }
       else if (Controller.ButtonL2.pressing())
       {
         CubeAngleMotor.spin(vex::directionType::rev);
       }
       else
       {
         CubeAngleMotor.stop();
       }
 
       //Lift Section
       LeftLiftMotor.setVelocity(liftSpeedPCT, vex::percentUnits::pct);
       RightLiftMotor.setVelocity(liftSpeedPCT, vex::percentUnits::pct);
 
       if(Controller.ButtonR1.pressing())
       {
         LeftLiftMotor.spin(vex::directionType::fwd);
         RightLiftMotor.spin(vex::directionType::rev);
       }
       else if (Controller.ButtonR2.pressing())
       {
         LeftLiftMotor.spin(vex::directionType::rev);
         RightLiftMotor.spin(vex::directionType::fwd);
       }
       else
       {
         LeftLiftMotor.stop();
         RightLiftMotor.stop();
       }
       // Intake Section
       LeftIntakeMotor.setVelocity(intakeSpeedPCT, vex::percentUnits::pct);
       RightIntakeMotor.setVelocity(intakeSpeedPCT, vex::percentUnits::pct);
 
       if(Controller2.ButtonX.pressing())
       {
         LeftIntakeMotor.spin(vex::directionType::rev);
         RightIntakeMotor.spin(vex::directionType::fwd);
       }
       else if (Controller2.ButtonB.pressing())
       {
         LeftIntakeMotor.spin(vex::directionType::fwd);
         RightIntakeMotor.spin(vex::directionType::rev);
       }
       else
       {
         LeftIntakeMotor.stop();
         RightIntakeMotor.stop();
       }
       vex::task::sleep(10); 
       // Combined Functions
       if(Controller.ButtonA.pressing())
       {
         LeftIntakeMotor.spin(vex::directionType::fwd);
         RightIntakeMotor.spin(vex::directionType::rev);
         LeftMotor.spin(vex::directionType::fwd, 50, vex::percentUnits::pct);
         RightMotor.spin(vex::directionType::fwd, 50, vex::percentUnits::pct);
       }
       else
       {
         LeftIntakeMotor.stop();
         RightIntakeMotor.stop();
         LeftMotor.stop();
         RightMotor.stop();
       }
 
     }
 }
 