/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       VEX                                                       */
/*    Created:      Thu Sep 26 2019                                           */
/*    Description:  Competition Template                                      */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"

using namespace vex;

// A global instance of competition
competition Competition;

// define your global instances of motors and other devices here

/*---------------------------------------------------------------------------*/
/*                          Pre-Autonomous Functions                         */
/*                                                                           */
/*  You may want to perform some actions before the competition starts.      */
/*  Do them in the following function.  You must return from this function   */
/*  or the autonomous and usercontrol tasks will not be started.  This       */
/*  function is only called once after the V5 has been powered on and        */
/*  not every time that the robot is disabled.                               */
/*---------------------------------------------------------------------------*/

void pre_auton(void) {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();
  
  // define your global instances of motors and other devices here


  // All activities that occur before the competition starts
  // Example: clearing encoders, setting servo positions, ...
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              Autonomous Task                              */
/*                                                                           */
/*  This task is used to control your robot during the autonomous phase of   */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/

void autonomous(void) {
 vex::task::sleep(100);

 //Go forwards 6.2 ft
 Brain.Screen.print("forwards");
 Brain.Screen.newLine();
  vex::motor lm = vex::motor(vex::PORT12);
  vex::motor rm = vex::motor(vex::PORT19);\
  vex::motor angler = vex::motor(vex::PORT2);
  vex::gyro gscope = vex::gyro(Brain.ThreeWirePort.B);
  vex::motor in1 = vex::motor(vex::PORT11);
  vex::motor in2 = vex::motor(vex::PORT20);

  gscope.calibrate();
  waitUntil(!gscope.isCalibrating());
  
 lm.setVelocity(70, vex::velocityUnits::pct);
 rm.setVelocity(70, vex::velocityUnits::pct);
 lm.rotateFor(2126, vex::rotationUnits::deg, false);
 rm.rotateFor(2126, vex::rotationUnits::deg);
 vex::task::sleep(5000);
 
 //turn 90 deg left
 Brain.Screen.print("left");
 Brain.Screen.newLine();
 lm.setVelocity(50, vex::velocityUnits::pct);
 rm.setVelocity(50, vex::velocityUnits::pct);
 //Gyro timeeeeee
 gscope.setHeading(0, degrees);
 lm.spin(reverse);
 rm.spin(forward);
 waitUntil(gscope.heading() < 288);
 lm.stop();
 rm.stop(); 
 vex::task::sleep(100);
 
 //Set move velocities to 70, intake to 100
 lm.setVelocity(70, vex::velocityUnits::pct);
 rm.setVelocity(70, vex::velocityUnits::pct);
 in1.setVelocity(100, vex::velocityUnits::pct);
 in2.setVelocity(100, vex::velocityUnits::pct);
 
 //forwards 2.1 ft (720 degrees) and intake
 Brain.Screen.print("forwards");
 Brain.Screen.newLine();
 in1.spin(fwd);
 in2.spin(reverse);
 lm.rotateFor(720, vex::rotationUnits::deg, false);
 rm.rotateFor(720, vex::rotationUnits::deg);
 in1.stop();
 in2.stop();
 vex::task::sleep(100);
 
 //back up 5 in (143 in)
 Brain.Screen.print("backwards");
 Brain.Screen.newLine();
 lm.rotateFor(-143, vex::rotationUnits::deg, false);
 rm.rotateFor(-143, vex::rotationUnits::deg);
 vex::task::sleep(2000);
 
 //turn 135 right
 Brain.Screen.print("right");
 Brain.Screen.newLine();
 lm.setVelocity(50, vex::velocityUnits::pct);
 rm.setVelocity(50, vex::velocityUnits::pct);
 gscope.setHeading(0, degrees);
 lm.spin(forward);
 rm.spin(reverse);
 waitUntil(gscope.heading () > 117);
 lm.stop();
 rm.stop();
 
 //forwards 1.4ft (485 deg)
 Brain.Screen.print("final push");
 Brain.Screen.newLine();
 lm.setVelocity(70, vex::velocityUnits::pct);
 rm.setVelocity(70, vex::velocityUnits::pct);
 lm.rotateFor(485, vex::rotationUnits::deg, false);
 rm.rotateFor(485, vex::rotationUnits::deg);
 vex::task::sleep(100);

 //raise block holder
 Brain.Screen.print("angler");
 Brain.Screen.newLine();
 angler.setVelocity(25, vex::velocityUnits::pct);
 angler.rotateFor(288, vex::rotationUnits::deg);

 //Back half a foot and outake
 Brain.Screen.print("Back and stuff");
 Brain.Screen.newLine();
 lm.setVelocity(50, vex::velocityUnits::pct);
 rm.setVelocity(50, vex::velocityUnits::pct);
 in1.spin(reverse);
 in2.spin(forward);
 lm.rotateFor(-343, vex::rotationUnits::deg, false);
 rm.rotateFor(-343, vex::rotationUnits::deg);
 in1.stop();
 in2.stop();
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              User Control Task                            */
/*                                                                           */
/*  This task is used to control your robot during the user control phase of */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/

void usercontrol(void) {
  // User control code here, inside the loop

  vex::motor LeftMotor = vex::motor(vex::PORT12);
  vex::motor RightMotor = vex::motor(vex::PORT19);
  vex::motor StrafeMotor = vex::motor(vex::PORT15);
  vex::motor CubeAngleMotor = vex::motor(vex::PORT2); 
  vex::motor LeftLiftMotor = vex::motor(vex::PORT1);
  vex::motor RightLiftMotor = vex::motor(vex::PORT21); 
  vex::motor LeftIntakeMotor = vex::motor(vex::PORT11);
  vex::motor RightIntakeMotor = vex::motor(vex::PORT20);

  vex::controller Controller (vex::controllerType::primary);
  vex::controller Controller2 (vex::controllerType::partner);
  int deadzone = 20;
  int cubeAngleSpeedPCT = 25;
  int liftSpeedPCT = 100;
  int intakeSpeedPCT = 100;
  while(1) 
  { 
    // Drivetrain Section (Arcade Style)
    //Axis 2 (right joystick horizontal acis) of the controller makes the robot moves forward or backward and Ax
    if(abs(Controller.Axis2.position()) > deadzone || abs(Controller.Axis1.position()) > deadzone )
     {
         LeftMotor.spin(vex::directionType::fwd, Controller.Axis2.position(), vex::percentUnits::pct);
         RightMotor.spin(vex::directionType::rev, Controller.Axis2.position(), vex::percentUnits::pct);
         StrafeMotor.spin(vex::directionType::rev, Controller.Axis1.position(), vex::percentUnits::pct);
       }
       else if(abs(Controller.Axis4.position()) > deadzone)
       {
         LeftMotor.spin(vex::directionType::fwd, Controller.Axis4.position()/3, vex::percentUnits::pct);
         RightMotor.spin(vex::directionType::fwd, Controller.Axis4.position()/3, vex::percentUnits::pct);
         StrafeMotor.spin(vex::directionType::fwd, Controller.Axis4.position()/3, vex::percentUnits::pct);
       }
       else
       {
         LeftMotor.stop();
         RightMotor.stop();
         StrafeMotor.stop();
       }
 
       // Cube Angle Section
       CubeAngleMotor.setVelocity(cubeAngleSpeedPCT, vex::percentUnits::pct);
       
       if(Controller.ButtonL1.pressing() || Controller2.ButtonL1.pressing())
       {
         CubeAngleMotor.spin(vex::directionType::fwd);
       }
       else if (Controller.ButtonL2.pressing() || Controller2.ButtonL2.pressing())
       {
         CubeAngleMotor.spin(vex::directionType::rev);
       }
       else
       {
         CubeAngleMotor.stop();
       }
 
       //Lift Section
       LeftLiftMotor.setVelocity(liftSpeedPCT, vex::percentUnits::pct);
       RightLiftMotor.setVelocity(liftSpeedPCT, vex::percentUnits::pct);
 
       if(Controller.ButtonR1.pressing())
       {
         LeftLiftMotor.spin(vex::directionType::fwd);
         RightLiftMotor.spin(vex::directionType::rev);
       }
       else if (Controller.ButtonR2.pressing())
       {
         LeftLiftMotor.spin(vex::directionType::rev);
         RightLiftMotor.spin(vex::directionType::fwd);
       }
       else
       {
         LeftLiftMotor.stop();
         RightLiftMotor.stop();
       }
       // Intake Section
       LeftIntakeMotor.setVelocity(intakeSpeedPCT, vex::percentUnits::pct);
       RightIntakeMotor.setVelocity(intakeSpeedPCT, vex::percentUnits::pct);
 
       if(Controller2.ButtonX.pressing())
       {
         LeftIntakeMotor.spin(vex::directionType::rev);
         RightIntakeMotor.spin(vex::directionType::fwd);
       }
       else if (Controller2.ButtonB.pressing())
       {
         LeftIntakeMotor.spin(vex::directionType::fwd);
         RightIntakeMotor.spin(vex::directionType::rev);
       }
       else
       {
         LeftIntakeMotor.stop();
         RightIntakeMotor.stop();
       }
       vex::task::sleep(10); 
       // Combined Functions
       if(Controller.ButtonA.pressing())
       {
         LeftIntakeMotor.spin(vex::directionType::fwd);
         RightIntakeMotor.spin(vex::directionType::rev);
         LeftMotor.spin(vex::directionType::fwd, 50, vex::percentUnits::pct);
         RightMotor.spin(vex::directionType::fwd, 50, vex::percentUnits::pct);
       }
       else
       {
         LeftIntakeMotor.stop();
         RightIntakeMotor.stop();
         LeftMotor.stop();
         RightMotor.stop();
       }
  }
}
int main() {
  // Set up callbacks for autonomous and driver control periods.
  Competition.autonomous(autonomous);
  Competition.drivercontrol(usercontrol);

  // Run the pre-autonomous function.
  pre_auton();

  // Prevent main from exiting with an infinite loop.
  while (true) {
    wait(100, msec);
  }
}